# oaxai configuration for nginx
This repo includes various config files for the Oaxai Server and each of the elements installed with that stack.
